package com.example.orgsocial.utils;

import android.view.View;

public interface groupParticipantsClickListener {
    void onClick(View view, int posiiton);
}
