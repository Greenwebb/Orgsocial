package com.example.orgsocial;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.example.orgsocial.adapters.GroupParticipantsAdapter;
import com.example.orgsocial.databinding.ActivityGroupProfileBinding;
import com.example.orgsocial.models.GroupUser;
import com.google.android.gms.common.util.DataUtils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GroupProfileActivity extends AppCompatActivity {
    ActivityGroupProfileBinding binding;
    String groupPhoto,groupName,groupId;
    List<GroupUser>list = new ArrayList<>();
    FirebaseUser currentuser;
    FirebaseFirestore store;
    GroupParticipantsAdapter Adapter;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,R.layout.activity_group_profile);
        Intent intent = getIntent();
        Adapter = new GroupParticipantsAdapter(list,this);
        binding.participantsRecycler.setLayoutManager(new LinearLayoutManager(this));
        binding.participantsRecycler.setAdapter(Adapter);
        groupPhoto = intent.getStringExtra("userPhotoUrl");
        groupName = intent.getStringExtra("userName");
        groupId = intent.getStringExtra("groupId");
        currentuser = FirebaseAuth.getInstance().getCurrentUser();
        store = FirebaseFirestore.getInstance();
        binding.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        if(groupPhoto.equals("")){
            binding.profileImage.setImageDrawable(getDrawable(R.drawable.ic_group_14));
            binding.progress.setVisibility(View.GONE);
        }else{
            Glide.with(this).load(groupPhoto).addListener(new RequestListener<Drawable>() {
                @Override
                public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                    return false;
                }

                @Override
                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                    binding.progress.setVisibility(View.GONE);
                    return false;
                }
            }).into(binding.profileImage);

        }
        binding.username.setText(groupName);
         getGroupInfo();
    }
   public void getGroupInfo(){
       binding.participantsCount.setVisibility(View.GONE);
       store.collection("Groups").document(groupId).collection("Participants").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
           @Override
           public void onComplete(@NonNull Task<QuerySnapshot> task) {
               if (task.isSuccessful()) {
                   List<DocumentSnapshot> myListOfDocuments = task.getResult().getDocuments();
                   for(DocumentSnapshot current : myListOfDocuments){
                       String userId = current.getString("userId");
                       String name = current.get("userName").toString();
                       Boolean admin = current.getBoolean("admin");
                       Boolean creator = current.getBoolean("creator");
                       String Description = current.get("description").toString();
                       String Email = current.getString("userEmail");
                       String phone = current.getString("userPhone");
                       String photo = current.getString("userPhotoUrl");

                       GroupUser currentUser = new GroupUser(userId,name,Email,phone,photo,Description,admin,creator);
                       if(userId.equals(currentuser.getUid())){
                       }else{
                           list.add(currentUser);
       git                 }

                   }
                   Adapter.notifyDataSetChanged();
                   binding.participantsCount.setText(list.size()+1+" Participants");
                   binding.participantsCount.setVisibility(View.VISIBLE);

               }
           }
       });
    }
}