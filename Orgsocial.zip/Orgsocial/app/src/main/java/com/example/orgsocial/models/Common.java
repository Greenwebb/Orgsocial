package com.example.orgsocial.models;

import android.graphics.Bitmap;

public class Common {
    public static Bitmap IMAGE_BITMAP;
}
