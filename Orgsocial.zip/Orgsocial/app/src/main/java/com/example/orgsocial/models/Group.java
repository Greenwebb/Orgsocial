package com.example.orgsocial.models;

import android.app.MediaRouteActionProvider;

import androidx.annotation.Keep;

import com.google.firebase.database.ServerValue;
import com.google.firebase.firestore.ServerTimestamp;
import com.google.firestore.v1.DocumentTransform;


import java.io.Serializable;
import java.util.Date;
import java.util.List;


public class Group implements Serializable {

    private List<User> participants;
    private String groupPhotoUrl;
    private String groupId;
    private String groupSubject;
    private String creator;
    @ServerTimestamp Date dateCreated;
    private List<User> admins;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public Group() {
    }


    public Group(List<User> participants, String groupPhotoUrl, String groupId, String groupSubject, String creator, List<User> admins) {
        this.participants = participants;
        this.groupPhotoUrl = groupPhotoUrl;
        this.groupId = groupId;
        this.groupSubject = groupSubject;
        this.creator = creator;
        this.admins = admins;
    }

    public List<User> getParticipants() {
        return participants;
    }

    public void setParticipants(List<User> participants) {
        this.participants = participants;
    }

    public String getGroupPhotoUrl() {
        return groupPhotoUrl;
    }

    public void setGroupPhotoUrl(String groupPhotoUrl) {
        this.groupPhotoUrl = groupPhotoUrl;
    }

    public String getGroupSubject() {
        return groupSubject;
    }

    public void setGroupSubject(String groupSubject) {
        this.groupSubject = groupSubject;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public List<User> getAdmins() {
        return admins;
    }

    public void setAdmins(List<User> admins) {
        this.admins = admins;
    }
}
