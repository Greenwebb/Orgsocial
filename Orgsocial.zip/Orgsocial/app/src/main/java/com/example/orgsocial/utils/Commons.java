package com.example.orgsocial.utils;

import com.example.orgsocial.models.User;

public class Commons {
   public static User currentUser;
}
